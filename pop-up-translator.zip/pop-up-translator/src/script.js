
function Translate()
{
  var targetLanguage = $("input.targetLanguage").val();
  var inputText = $("input.inputText").val();
  var url = 
      "https://translate.google.com/?hl=en&ui=tob&sl=en&tl=" + targetLanguage + "&text=" + inputText + "&op=translate";


  window.open(url,height=50, width=50,top=50,left=50)

}

